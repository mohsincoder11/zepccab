@component('mail::message')
       @component('mail::panel')
        ### Message: {{$content['message']}}
    @endcomponent

    Thanks
    Team Zhep Cab Tours and Travels, Amravati
@endcomponent
